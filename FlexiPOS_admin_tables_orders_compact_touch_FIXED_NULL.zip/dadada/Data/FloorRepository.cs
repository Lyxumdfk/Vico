﻿using Flexi2.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Flexi2.Data
{
    public sealed class FloorRepository
    {
        public FloorRepository()
        {
        }

        public int AddZone(string name)
        {
            var row = new SupabaseZoneRow
            {
                Name = name
            };

            var result = App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Insert(row)
                .GetAwaiter()
                .GetResult();

            return result.Models.First().Id;
        }

        public void DeleteZone(int zoneId)
        {
            var tables = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("zone_id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Get()
                .GetAwaiter()
                .GetResult();

            if (tables.Models.Count > 0)
                throw new InvalidOperationException("Зоната има маси. Първо изтрий масите.");

            App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Delete()
                .GetAwaiter()
                .GetResult();
        }

        public int AddTable(int zoneId, string name, int shapeType = 0)
        {
            var existingTables = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("zone_id", Supabase.Postgrest.Constants.Operator.Equals, zoneId)
                .Get()
                .GetAwaiter()
                .GetResult();

            var idx = existingTables.Models.Count;
            var x = 20 + (idx % 4) * 190;
            var y = 20 + (idx / 4) * 140;

            var defaultWidth = shapeType == 1 ? 230 : 170;
            var defaultHeight = shapeType == 1 ? 120 : 170;

            var row = new SupabaseTableRow
            {
                ZoneId = zoneId,
                Name = name,
                PosX = x,
                PosY = y,
                Width = defaultWidth,
                Height = defaultHeight,
                ShapeType = shapeType,
                Status = 0,
                OwnerUserId = null,
                OpenedAtUtc = null,
                CurrentTotal = 0m
            };

            var result = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Insert(row)
                .GetAwaiter()
                .GetResult();

            return result.Models.First().Id;
        }

        public void UpdateTableLayout(int tableId, double x, double y, double? width = null, double? height = null)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.PosX = x;
            table.PosY = y;

            if (width.HasValue)
                table.Width = width.Value;

            if (height.HasValue)
                table.Height = height.Value;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void UpdateTableShape(int tableId, int shapeType, double width, double height)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.ShapeType = shapeType;
            table.Width = width;
            table.Height = height;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void DeleteTable(int tableId)
        {
            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Delete()
                .GetAwaiter()
                .GetResult();
        }

        public List<ZoneModel> GetZones()
        {
            var zoneRows = App.SupabaseClient
                .From<SupabaseZoneRow>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .OrderBy(z => z.Id)
                .ToList();

            var tableRows = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .OrderBy(t => t.ZoneId)
                .ThenBy(t => t.Id)
                .ToList();

            var usersById = App.SupabaseClient
                .From<User>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .ToDictionary(u => u.Id, u => u.Name);

            // Компактна информация за поръчките, за да може в Админ -> Маси и зони
            // да се вижда какво има в заетата маса, без да се отваря самата сметка.
            var openOrders = App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("status", Supabase.Postgrest.Constants.Operator.Equals, "open")
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .GroupBy(o => o.TableId)
                .ToDictionary(g => g.Key, g => g.OrderByDescending(o => o.Id).First());

            var orderItems = App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Get()
                .GetAwaiter()
                .GetResult()
                .Models
                .ToList();

            var orderPreviewByTable = openOrders.ToDictionary(
                pair => pair.Key,
                pair =>
                {
                    var items = orderItems
                        .Where(i => i.OrderId == pair.Value.Id)
                        .GroupBy(i => i.ProductName)
                        .Select(g => new
                        {
                            Name = g.Key,
                            Qty = g.Sum(x => x.Quantity),
                            Total = g.Sum(x => x.Price * x.Quantity)
                        })
                        .Where(x => x.Qty != 0)
                        .OrderByDescending(x => x.Total)
                        .ToList();

                    if (items.Count == 0)
                        return string.Empty;

                    var visibleItems = items
                        .Take(3)
                        .Select(x => $"{x.Qty}x {x.Name}");

                    var text = string.Join(", ", visibleItems);
                    if (items.Count > 3)
                        text += $", + още {items.Count - 3}";

                    return text;
                });

            var zones = zoneRows.Select(z => new ZoneModel
            {
                Id = z.Id,
                Name = z.Name,
                Tables = new List<TableModel>()
            }).ToList();

            foreach (var zone in zones)
            {
                var tablesForZone = tableRows
                    .Where(t => t.ZoneId == zone.Id)
                    .Select(t => new TableModel
                    {
                        Id = t.Id,
                        ZoneId = t.ZoneId,
                        Name = t.Name,
                        PosX = t.PosX,
                        PosY = t.PosY,
                        Width = t.Width,
                        Height = t.Height,
                        ShapeType = t.ShapeType,
                        Status = (TableStatus)t.Status,
                        OwnerUserId = t.OwnerUserId,
                        OwnerUserName = t.OwnerUserId.HasValue && usersById.TryGetValue(t.OwnerUserId.Value, out var ownerName)
                            ? ownerName
                            : string.Empty,
                        OpenedAtUtc = string.IsNullOrWhiteSpace(t.OpenedAtUtc)
                            ? null
                            : DateTime.Parse(t.OpenedAtUtc, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind),
                        CurrentTotal = t.CurrentTotal,
                        AdminOrderPreview = orderPreviewByTable.TryGetValue(t.Id, out var preview)
                            ? preview
                            : string.Empty
                    })
                    .ToList();

                zone.Tables = tablesForZone;
            }

            return zones;
        }

        public void SetTableOccupied(int tableId, int ownerUserId)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.Status = 1;
            table.OwnerUserId = ownerUserId;
            table.OpenedAtUtc = DateTime.UtcNow.ToString("O");

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void SetTableFree(int tableId)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.Status = 0;
            table.OwnerUserId = null;
            table.OpenedAtUtc = null;
            table.CurrentTotal = 0m;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }

        public void UpdateTableTotal(int tableId, decimal total)
        {
            var table = App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, tableId)
                .Single()
                .GetAwaiter()
                .GetResult();

            table.CurrentTotal = total;

            App.SupabaseClient
                .From<SupabaseTableRow>()
                .Update(table)
                .GetAwaiter()
                .GetResult();
        }
    }
}