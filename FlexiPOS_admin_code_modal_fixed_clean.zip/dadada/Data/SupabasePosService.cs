﻿using Flexi2.Models;
using Supabase.Realtime.PostgresChanges;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using static Supabase.Postgrest.Constants;
using static Supabase.Realtime.PostgresChanges.PostgresChangesOptions;

namespace Flexi2.Data
{
    public sealed class SupabasePosService
    {
        public async Task<long> LogLoginAsync(User user)
        {
            var row = new LoginLogRow
            {
                UserId = user.Id,
                Username = user.Name,
                RoleValue = user.RoleValue,
                LoginAt = DateTime.UtcNow
            };

            var result = await App.SupabaseClient
                .From<LoginLogRow>()
                .Insert(row);

            return result.Models.First().Id;
        }

        public async Task LogLogoutAsync(long loginLogId)
        {
            await App.SupabaseClient
                .From<LoginLogRow>()
                .Filter("id", Operator.Equals, loginLogId.ToString())
                .Set(x => x.LogoutAt, DateTime.UtcNow)
                .Update();
        }

        public async Task<SupabaseOrderRow> EnsureOpenOrderAsync(int tableId, int userId)
        {
            await VerifyTableAccessAsync(tableId, userId);

            var existing = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("table_id", Operator.Equals, tableId.ToString())
                .Filter("status", Operator.Equals, "open")
                .Get();

            var open = existing.Models
                .OrderByDescending(x => x.Id)
                .FirstOrDefault();

            if (open != null)
            {
                var ownerId = open.CreatedByUserId ?? open.UserId;
                if (ownerId != userId)
                    throw new InvalidOperationException("Тази маса има отворена сметка от друг сервитьор. Нямате право да я пипате.");

                return open;
            }

            var newOrder = new SupabaseOrderRow
            {
                UserId = userId,
                CreatedByUserId = userId,
                TableId = tableId,
                CreatedAt = DateTime.UtcNow,
                Status = "open",
                TotalPrice = 0,
                Subtotal = 0,
                PaidTotal = 0
            };

            var inserted = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Insert(newOrder);

            return inserted.Models.First();
        }

        public async Task AddItemsAsync(int orderId, int userId, IEnumerable<OrderItem> items)
        {
            var rows = items.Select(x => new SupabaseOrderItemRow
            {
                OrderId = orderId,
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                Quantity = x.Qty,
                Price = x.UnitPrice,
                OrderedAt = DateTime.UtcNow,
                OrderedByUserId = userId
            }).ToList();

            if (rows.Count == 0)
                return;

            await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Insert(rows);

            await RefreshOrderTotalAsync(orderId);
        }

        public async Task<decimal> GetOpenOrderTotalAsync(int orderId)
        {
            var items = await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Filter("order_id", Operator.Equals, orderId.ToString())
                .Get();

            return items.Models.Sum(x => x.Price * x.Quantity);
        }

        public async Task<List<OrderItem>> GetOpenOrderItemsByTable(int tableId, int? userId = null)
        {
            if (userId.HasValue)
                await VerifyTableAccessAsync(tableId, userId.Value);

            var openOrder = await GetLatestOpenOrderByTableAsync(tableId);
            if (openOrder == null)
                return new List<OrderItem>();

            if (userId.HasValue)
            {
                var ownerId = openOrder.CreatedByUserId ?? openOrder.UserId;
                if (ownerId != userId.Value)
                    throw new InvalidOperationException("Тази маса има отворена сметка от друг сервитьор. Нямате право да я отваряте.");
            }

            var items = await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Filter("order_id", Operator.Equals, openOrder.Id.ToString())
                .Get();

            return items.Models
                .GroupBy(x => new { x.ProductId, x.ProductName, x.Price })
                .Select(g => new OrderItem
                {
                    Id = g.Min(x => x.Id),
                    OrderId = g.First().OrderId,
                    ProductId = g.Key.ProductId,
                    ProductName = g.Key.ProductName,
                    UnitPrice = g.Key.Price,
                    Qty = g.Sum(x => x.Quantity),
                    IsLocked = true
                })
                .Where(x => x.Qty != 0)
                .OrderBy(x => x.Id)
                .ToList();
        }

        public async Task RefreshOrderTotalAsync(int orderId)
        {
            var total = await GetOpenOrderTotalAsync(orderId);

            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, orderId.ToString())
                .Set(x => x.Subtotal, total)
                .Set(x => x.TotalPrice, total)
                .Update();
        }

        public async Task CloseOrderAsync(int tableId, int userId, string paymentMethod, decimal discountPercent, decimal tipAmount)
        {
            await VerifyTableAccessAsync(tableId, userId);

            var openOrder = await GetLatestOpenOrderByTableAsync(tableId);
            if (openOrder == null)
                return;

            var ownerId = openOrder.CreatedByUserId ?? openOrder.UserId;
            if (ownerId != userId)
                throw new InvalidOperationException("Само сервитьорът, който е отворил масата, може да приключи сметката.");

            var subtotal = await GetOpenOrderTotalAsync(openOrder.Id);

            if (discountPercent < 0) discountPercent = 0;
            if (discountPercent > 100) discountPercent = 100;
            if (tipAmount < 0) tipAmount = 0;

            var discountAmount = subtotal * (discountPercent / 100m);
            var finalTotal = (subtotal - discountAmount) + tipAmount;

            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, openOrder.Id.ToString())
                .Set(x => x.Subtotal, subtotal)
                .Set(x => x.DiscountPercent, discountPercent)
                .Set(x => x.DiscountAmount, discountAmount)
                .Set(x => x.TipAmount, tipAmount)
                .Set(x => x.PaidTotal, finalTotal)
                .Set(x => x.TotalPrice, finalTotal)
                .Set(x => x.PaymentMethod!, paymentMethod)
                .Set(x => x.Status!, "paid")
                .Set(x => x.ClosedAt, DateTime.UtcNow)
                .Update();

            var tableResult = await App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Operator.Equals, tableId.ToString())
                .Get();

            var table = tableResult.Models.FirstOrDefault();
            if (table != null)
            {
                table.Status = 0;
                table.OwnerUserId = null;
                table.OpenedAtUtc = null;
                table.CurrentTotal = 0m;

                await App.SupabaseClient
                    .From<SupabaseTableRow>()
                    .Update(table);
            }
        }


        public async Task VerifyTableAccessAsync(int tableId, int userId)
        {
            var tableResult = await App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Operator.Equals, tableId.ToString())
                .Get();

            var table = tableResult.Models.FirstOrDefault();
            if (table == null)
                throw new InvalidOperationException("Масата не е намерена.");

            if (table.Status == 1 && table.OwnerUserId.HasValue && table.OwnerUserId.Value != userId)
                throw new InvalidOperationException("Тази маса е заета от друг сервитьор. Само той може да влиза, да поръчва и да приключва сметката.");

            if (table.Status == 1 && !table.OwnerUserId.HasValue)
                throw new InvalidOperationException("Тази маса е заета, но няма записан сервитьор. Сметката е заключена.");
        }

        public async Task<SupabaseOrderRow?> GetLatestOpenOrderByTableAsync(int tableId)
        {
            var result = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("table_id", Operator.Equals, tableId.ToString())
                .Filter("status", Operator.Equals, "open")
                .Get();

            return result.Models
                .OrderByDescending(x => x.Id)
                .FirstOrDefault();
        }

        public async Task StartRealtimeAsync(Action onOrdersChanged, Action onLoginsChanged)
        {
            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onOrdersChanged);
                });

            await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onOrdersChanged);
                });

            await App.SupabaseClient
                .From<LoginLogRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onLoginsChanged);
                });
        }

        public async Task PlaceOrderAsync(int tableId, int userId, List<OrderItem> items)
        {
            if (items == null || items.Count == 0)
                return;

            var order = await EnsureOpenOrderAsync(tableId, userId);

            await AddItemsAsync(order.Id, userId, items);

            var refreshedOrder = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, order.Id.ToString())
                .Get();

            var latestOrder = refreshedOrder.Models.FirstOrDefault();
            var total = latestOrder?.TotalPrice ?? 0m;

            var tableResult = await App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Operator.Equals, tableId.ToString())
                .Get();

            var table = tableResult.Models.FirstOrDefault();
            if (table != null)
            {
                table.Status = 1;
                table.OwnerUserId = userId;
                table.OpenedAtUtc = DateTime.UtcNow.ToString("O");
                table.CurrentTotal = total;

                await App.SupabaseClient
                    .From<SupabaseTableRow>()
                    .Update(table);
            }
        }
    }
}