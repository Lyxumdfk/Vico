﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Flexi2.Models;
using Flexi2.ViewModels;

namespace Flexi2.Views
{
    public partial class AdminFloorView : UserControl
    {
        private double _scaleX = 1.0;
        private double _scaleY = 1.0;
        private AdminFloorViewModel? _subscribedVm;

        public AdminFloorView()
        {
            InitializeComponent();
            Loaded += (_, _) => ApplyAdaptiveAdminLayout();
            DataContextChanged += (_, _) => SubscribeToTablesCollection();
        }

        private void SubscribeToTablesCollection()
        {
            if (_subscribedVm != null)
                _subscribedVm.Tables.CollectionChanged -= Tables_CollectionChanged;

            _subscribedVm = DataContext as AdminFloorViewModel;

            if (_subscribedVm != null)
                _subscribedVm.Tables.CollectionChanged += Tables_CollectionChanged;

            Dispatcher.BeginInvoke(new Action(ApplyAdaptiveAdminLayout));
        }

        private void Tables_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
            => Dispatcher.BeginInvoke(new Action(ApplyAdaptiveAdminLayout));

        private void AdminTablesControl_Loaded(object sender, RoutedEventArgs e)
            => ApplyAdaptiveAdminLayout();

        private void AdminTablesControl_SizeChanged(object sender, SizeChangedEventArgs e)
            => ApplyAdaptiveAdminLayout();

        private void ApplyAdaptiveAdminLayout()
        {
            if (DataContext is not AdminFloorViewModel vm || vm.Tables.Count == 0)
                return;

            double availableWidth = AdminTablesControl.ActualWidth;
            double availableHeight = AdminTablesControl.ActualHeight;

            if (availableWidth <= 0 || availableHeight <= 0)
                return;

            double maxRight = vm.Tables.Max(t => t.PosX + t.Width);
            double maxBottom = vm.Tables.Max(t => t.PosY + t.Height);

            if (maxRight <= 0 || maxBottom <= 0)
                return;

            _scaleX = availableWidth / maxRight;
            _scaleY = availableHeight / maxBottom;

            foreach (var table in vm.Tables)
            {
                table.DisplayPosX = table.PosX * _scaleX;
                table.DisplayPosY = table.PosY * _scaleY;
                table.DisplayWidth = table.Width * _scaleX;
                table.DisplayHeight = table.Height * _scaleY;
            }
        }

        private void TableThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;

            table.PosX = Math.Max(0, table.PosX + (e.HorizontalChange / sx));
            table.PosY = Math.Max(0, table.PosY + (e.VerticalChange / sy));

            ApplyAdaptiveAdminLayout();
        }

        private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;

            var canvas = FindParent<Canvas>(thumb);
            var minWidth = canvas != null && canvas.ActualWidth > 0
                ? Math.Max(55, canvas.ActualWidth * 0.04 / sx)
                : 55;

            var minHeight = canvas != null && canvas.ActualHeight > 0
                ? Math.Max(55, canvas.ActualHeight * 0.04 / sy)
                : 55;

            var widthChange = e.HorizontalChange / sx;
            var heightChange = e.VerticalChange / sy;
            var newWidth = Math.Max(minWidth, table.Width + widthChange);
            var newHeight = Math.Max(minHeight, table.Height + heightChange);

            // Квадрат и кръг запазват еднаква ширина и височина при разтягане/свиване.
            if (table.ShapeType == 0 || table.ShapeType == 2)
            {
                var delta = Math.Abs(widthChange) >= Math.Abs(heightChange) ? widthChange : heightChange;
                var minSide = Math.Max(minWidth, minHeight);
                var side = Math.Max(minSide, table.Width + delta);
                table.Width = side;
                table.Height = side;
            }
            else
            {
                table.Width = newWidth;
                table.Height = newHeight;
            }

            ApplyAdaptiveAdminLayout();
        }

        private static T? FindParent<T>(DependencyObject child)
            where T : DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(child);

            while (parent != null)
            {
                if (parent is T typedParent)
                    return typedParent;

                parent = VisualTreeHelper.GetParent(parent);
            }

            return null;
        }

        private async void TableThumb_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            // Persist layout immediately when the drag ends
            if (DataContext is AdminFloorViewModel vm)
                await vm.SaveTableLayoutAsync(table);
        }
    }
}
