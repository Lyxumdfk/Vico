﻿using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Flexi2.ViewModels
{
    public sealed class TicketViewModel : ObservableObject
    {
        private readonly MainViewModel _main;
        public int TableId { get; }

        public ObservableCollection<OrderItem> LockedItems { get; } = new();
        public ObservableCollection<OrderItem> DraftItems { get; } = new();

        private string _title = "";
        public string Title
        {
            get => _title;
            set => Set(ref _title, value);
        }

        private decimal _total;
        public decimal Total
        {
            get => _total;
            set => Set(ref _total, value);
        }

        private string _error = "";
        public string Error
        {
            get => _error;
            set => Set(ref _error, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set => Set(ref _isBusy, value);
        }

        public RelayCommand BackToFloorCommand { get; }
        public RelayCommand AddItemsCommand { get; }
        public RelayCommand IncDraftCommand { get; }
        public RelayCommand DecDraftCommand { get; }
        public RelayCommand RemoveLockedItemCommand { get; }
        public RelayCommand PlaceOrderCommand { get; }
        public RelayCommand CloseBillCommand { get; }

        public TicketViewModel(MainViewModel main, int tableId)
        {
            _main = main;
            TableId = tableId;

            Error = "";

            BackToFloorCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new FloorPlanViewModel(_main)));

            AddItemsCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new CategoryViewModel(_main, tableId, this)));

            IncDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;

                if (it.Qty < 0)
                {
                    it.Qty++;
                    if (it.Qty == 0)
                        DraftItems.Remove(it);
                }
                else
                {
                    it.Qty++;
                }

                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            DecDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;

                if (it.Qty < 0)
                {
                    var lockedQty = LockedItems.Where(x => x.ProductId == it.ProductId && x.ProductName == it.ProductName).Sum(x => x.Qty);
                    if (Math.Abs(it.Qty) < lockedQty)
                        it.Qty--;
                    else
                        Error = "Не може да махнете повече бройки, отколкото са поръчани.";
                }
                else if (it.Qty > 1)
                {
                    it.Qty--;
                }
                else
                {
                    DraftItems.Remove(it);
                }

                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            RemoveLockedItemCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem locked) return;
                AddRemovalDraft(locked);
            });

            PlaceOrderCommand = new RelayCommand(async _ => await PlaceOrderAsync(), _ => DraftItems.Count > 0 && !IsBusy);

            CloseBillCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Nav.NavigateTo(new PaymentViewModel(_main, this));
            });

            _ = LoadAsync();
        }

        public void AddDraftProduct(Product p)
        {
            var existing = DraftItems.FirstOrDefault(x => x.ProductId == p.Id && x.ProductName == p.Name);

            if (existing != null)
            {
                existing.Qty++;
                if (existing.Qty == 0)
                    DraftItems.Remove(existing);
            }
            else
            {
                DraftItems.Add(new OrderItem
                {
                    ProductId = p.Id,
                    ProductName = p.Name,
                    UnitPrice = p.Price,
                    Qty = 1,
                    IsLocked = false
                });
            }

            Recalc();
            PlaceOrderCommand.RaiseCanExecuteChanged();
        }

        private void AddRemovalDraft(OrderItem locked)
        {
            Error = "";

            var existingRemoval = DraftItems.FirstOrDefault(x =>
                x.ProductId == locked.ProductId &&
                x.ProductName == locked.ProductName &&
                x.Qty < 0);

            var alreadyMarked = Math.Abs(existingRemoval?.Qty ?? 0);
            var lockedQty = LockedItems.Where(x => x.ProductId == locked.ProductId && x.ProductName == locked.ProductName).Sum(x => x.Qty);

            if (alreadyMarked >= lockedQty)
            {
                Error = "Не може да махнете повече бройки, отколкото са поръчани.";
                return;
            }

            if (existingRemoval != null)
            {
                existingRemoval.Qty--;
            }
            else
            {
                DraftItems.Add(new OrderItem
                {
                    ProductId = locked.ProductId,
                    ProductName = locked.ProductName,
                    UnitPrice = locked.UnitPrice,
                    Qty = -1,
                    IsLocked = false
                });
            }

            Recalc();
            PlaceOrderCommand.RaiseCanExecuteChanged();
        }

        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                var lockedItems = await _main.PosService.GetOpenOrderItemsByTable(TableId, user.Id);

                var total = lockedItems.Sum(i => i.UnitPrice * i.Qty)
                            + DraftItems.Sum(i => i.UnitPrice * i.Qty);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    LockedItems.Clear();
                    foreach (var it in lockedItems)
                        LockedItems.Add(it);

                    Title = $"Сметка • Маса #{TableId}";
                    Total = total;
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }

        private void Recalc()
        {
            var locked = LockedItems.Sum(i => i.UnitPrice * i.Qty);
            var draft = DraftItems.Sum(i => i.UnitPrice * i.Qty);
            Total = locked + draft;
        }

        private static string? AskAdminPin()
        {
            var cyan = Color.FromRgb(0, 229, 255);
            var teal = Color.FromRgb(0, 255, 179);
            var neonRed = Color.FromRgb(255, 45, 80);
            var purple = Color.FromRgb(180, 0, 255);
            var modalBg = Color.FromRgb(7, 12, 24);
            var inputBg = Color.FromRgb(12, 23, 43);

            ControlTemplate RoundButtonTemplate(double radius)
            {
                var template = new ControlTemplate(typeof(Button));
                var border = new FrameworkElementFactory(typeof(Border));
                border.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
                border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Button.BackgroundProperty));
                border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Button.BorderBrushProperty));
                border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Button.BorderThicknessProperty));

                var content = new FrameworkElementFactory(typeof(ContentPresenter));
                content.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
                content.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
                content.SetValue(ContentPresenter.RecognizesAccessKeyProperty, true);
                border.AppendChild(content);
                template.VisualTree = border;
                return template;
            }

            var owner = Application.Current?.MainWindow;
            var oldEffect = owner?.Effect;
            if (owner != null)
            {
                owner.Effect = new System.Windows.Media.Effects.BlurEffect
                {
                    Radius = 13,
                    KernelType = System.Windows.Media.Effects.KernelType.Gaussian
                };
            }

            var win = new Window
            {
                Title = "Админ код",
                WindowStartupLocation = WindowStartupLocation.Manual,
                ResizeMode = ResizeMode.NoResize,
                Background = Brushes.Transparent,
                WindowStyle = WindowStyle.None,
                AllowsTransparency = true,
                ShowInTaskbar = false,
                Topmost = true
            };

            if (owner != null)
            {
                win.Owner = owner;
                win.Left = owner.Left;
                win.Top = owner.Top;
                win.Width = owner.ActualWidth > 0 ? owner.ActualWidth : owner.Width;
                win.Height = owner.ActualHeight > 0 ? owner.ActualHeight : owner.Height;
            }
            else
            {
                win.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                win.Width = 1000;
                win.Height = 650;
            }

            var overlay = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(220, 0, 4, 12))
            };

            var outer = new Border
            {
                Width = 460,
                MinHeight = 430,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                Background = new SolidColorBrush(modalBg),
                CornerRadius = new CornerRadius(20),
                BorderBrush = new SolidColorBrush(Color.FromRgb(64, 86, 130)),
                BorderThickness = new Thickness(1.5),
                Padding = new Thickness(26),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = cyan,
                    BlurRadius = 22,
                    ShadowDepth = 0,
                    Opacity = 0.34
                }
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var close = new Button
            {
                Content = "✕",
                Width = 44,
                Height = 44,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Top,
                FontFamily = new FontFamily("Segoe UI Symbol"),
                FontSize = 24,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(neonRed),
                Background = new SolidColorBrush(Color.FromRgb(24, 6, 16)),
                BorderBrush = new SolidColorBrush(neonRed),
                BorderThickness = new Thickness(2),
                Cursor = System.Windows.Input.Cursors.Hand,
                Template = RoundButtonTemplate(9),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = neonRed,
                    BlurRadius = 14,
                    ShadowDepth = 0,
                    Opacity = 0.45
                }
            };
            close.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            Grid.SetRow(close, 0);
            root.Children.Add(close);

            var lockCircle = new Border
            {
                Width = 96,
                Height = 96,
                CornerRadius = new CornerRadius(48),
                BorderBrush = new SolidColorBrush(cyan),
                BorderThickness = new Thickness(2),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 18, 0, 18),
                Background = new SolidColorBrush(Color.FromRgb(9, 20, 39)),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    Color = purple,
                    BlurRadius = 18,
                    ShadowDepth = 0,
                    Opacity = 0.35
                },
                Child = new TextBlock
                {
                    Text = "🔒",
                    FontSize = 38,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = new SolidColorBrush(cyan)
                }
            };
            Grid.SetRow(lockCircle, 1);
            root.Children.Add(lockCircle);

            var title = new TextBlock
            {
                Text = "АДМИН КОД",
                Foreground = new SolidColorBrush(cyan),
                FontSize = 29,
                FontWeight = FontWeights.Bold,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 12)
            };
            Grid.SetRow(title, 2);
            root.Children.Add(title);

            var msg = new TextBlock
            {
                Text = "Въведи админ код, за да запазиш\nмахането на продукт.",
                Foreground = Brushes.White,
                FontSize = 17,
                FontWeight = FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(0, 0, 0, 24)
            };
            Grid.SetRow(msg, 3);
            root.Children.Add(msg);

            var body = new StackPanel();

            var inputWrap = new Border
            {
                Height = 54,
                Background = new SolidColorBrush(inputBg),
                BorderBrush = new SolidColorBrush(teal),
                BorderThickness = new Thickness(2),
                CornerRadius = new CornerRadius(8),
                Padding = new Thickness(12, 0, 10, 0)
            };

            var inputGrid = new Grid();
            inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            inputGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var pass = new PasswordBox
            {
                Height = 48,
                FontSize = 18,
                Background = Brushes.Transparent,
                Foreground = Brushes.White,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0, 10, 8, 8),
                HorizontalContentAlignment = HorizontalAlignment.Left
            };
            Grid.SetColumn(pass, 0);
            inputGrid.Children.Add(pass);

            var placeholder = new TextBlock
            {
                Text = "Въведи админ код",
                Foreground = new SolidColorBrush(Color.FromRgb(165, 185, 220)),
                FontSize = 18,
                VerticalAlignment = VerticalAlignment.Center,
                IsHitTestVisible = false
            };
            Grid.SetColumn(placeholder, 0);
            inputGrid.Children.Add(placeholder);

            var shield = new TextBlock
            {
                Text = "▣",
                Foreground = new SolidColorBrush(Color.FromRgb(155, 205, 255)),
                FontSize = 22,
                Margin = new Thickness(14, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(shield, 1);
            inputGrid.Children.Add(shield);

            pass.PasswordChanged += (_, _) => placeholder.Visibility = string.IsNullOrEmpty(pass.Password) ? Visibility.Visible : Visibility.Collapsed;
            inputWrap.Child = inputGrid;
            body.Children.Add(inputWrap);

            var separator = new DockPanel { Margin = new Thickness(0, 22, 0, 22), HorizontalAlignment = HorizontalAlignment.Center };
            separator.Children.Add(new Border { Height = 1, Width = 145, Background = new SolidColorBrush(Color.FromRgb(58, 72, 100)), VerticalAlignment = VerticalAlignment.Center });
            separator.Children.Add(new TextBlock { Text = "🔒", Foreground = new SolidColorBrush(Color.FromRgb(155, 205, 255)), FontSize = 18, Margin = new Thickness(12, 0, 12, 0), VerticalAlignment = VerticalAlignment.Center });
            separator.Children.Add(new Border { Height = 1, Width = 145, Background = new SolidColorBrush(Color.FromRgb(58, 72, 100)), VerticalAlignment = VerticalAlignment.Center });
            body.Children.Add(separator);

            Button MakeDialogButton(string text, Brush background, Brush border, double width)
            {
                return new Button
                {
                    Content = text,
                    Width = width,
                    Height = 58,
                    FontSize = 16,
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.White,
                    Background = background,
                    BorderBrush = border,
                    BorderThickness = new Thickness(2),
                    Cursor = System.Windows.Input.Cursors.Hand,
                    Margin = new Thickness(8, 0, 8, 0),
                    Template = RoundButtonTemplate(14)
                };
            }

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            var cancel = MakeDialogButton("ОТКАЗ", new SolidColorBrush(Color.FromRgb(15, 25, 44)), new SolidColorBrush(Color.FromRgb(95, 120, 165)), 170);
            var ok = MakeDialogButton("ПОТВЪРДИ", new LinearGradientBrush(cyan, purple, 0), new SolidColorBrush(cyan), 190);
            ok.Click += (_, _) => { win.DialogResult = true; win.Close(); };
            cancel.Click += (_, _) => { win.DialogResult = false; win.Close(); };
            pass.KeyDown += (_, e) => { if (e.Key == System.Windows.Input.Key.Enter) { win.DialogResult = true; win.Close(); } };

            buttons.Children.Add(cancel);
            buttons.Children.Add(ok);
            body.Children.Add(buttons);

            Grid.SetRow(body, 4);
            root.Children.Add(body);

            outer.Child = root;
            overlay.Children.Add(outer);
            win.Content = overlay;
            win.Loaded += (_, _) => pass.Focus();
            win.Closed += (_, _) =>
            {
                if (owner != null)
                    owner.Effect = oldEffect;
            };

            return win.ShowDialog() == true ? pass.Password : null;
        }

        private async Task PlaceOrderAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                if (DraftItems.Any(x => x.Qty < 0))
                {
                    var pin = AskAdminPin();
                    if (string.IsNullOrWhiteSpace(pin))
                    {
                        Error = "Промяната не е запазена. Трябва админ код.";
                        return;
                    }

                    var admin = await _main.UsersRepo.TryLoginByPinAsync(pin, UserRole.Admin);
                    if (admin == null)
                    {
                        Error = "Грешен админ код. Промяната не е запазена.";
                        return;
                    }
                }

                var draftCopy = DraftItems.Where(d => d.Qty != 0).Select(d => new OrderItem
                {
                    ProductId = d.ProductId,
                    ProductName = d.ProductName,
                    UnitPrice = d.UnitPrice,
                    Qty = d.Qty,
                    IsLocked = true
                }).ToList();

                await _main.PosService.PlaceOrderAsync(TableId, user.Id, draftCopy);               

                Application.Current.Dispatcher.Invoke(() =>
                {
                    DraftItems.Clear();
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }
    }
}