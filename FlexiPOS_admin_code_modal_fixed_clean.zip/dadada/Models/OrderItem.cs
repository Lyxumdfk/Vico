﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Flexi2.Models
{
    public sealed class OrderItem : INotifyPropertyChanged
    {
        private int _qty;
        private decimal _unitPrice;

        public int Id { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; } = "";

        public decimal UnitPrice
        {
            get => _unitPrice;
            set
            {
                if (_unitPrice == value) return;
                _unitPrice = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Total));
                OnPropertyChanged(nameof(IsRemoval));
            }
        }

        public int Qty
        {
            get => _qty;
            set
            {
                if (_qty == value) return;
                _qty = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(Total));
                OnPropertyChanged(nameof(IsRemoval));
            }
        }

        public decimal Total => UnitPrice * Qty;

        public bool IsRemoval => Qty < 0;

        public bool IsLocked { get; set; } = true;

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
