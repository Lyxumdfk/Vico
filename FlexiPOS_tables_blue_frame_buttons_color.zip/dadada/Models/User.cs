﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using Newtonsoft.Json;

namespace Flexi2.Models
{
    [Table("users")]
    public class User : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; } = string.Empty;

        [Column("pinhash")]
        public string PinHash { get; set; } = string.Empty;

        [Column("pinsalt")]
        public string PinSalt { get; set; } = string.Empty;

        [Column("role")]
        public int RoleValue { get; set; }

        [Column("isactive")]
        public bool IsActive { get; set; }

        [Supabase.Postgrest.Attributes.Column("pin_code")]
        public string? PinCode { get; set; }

        [JsonIgnore]
        public UserRole Role
        {
            get => (UserRole)RoleValue;
            set => RoleValue = (int)value;
        }

        [JsonIgnore]
        public string PinDisplay => string.IsNullOrWhiteSpace(PinCode) ? "PIN: —" : $"PIN: {PinCode}";

        [JsonIgnore]
        public string RoleDisplay => Role == UserRole.Admin ? "Админ" : "POS";
    }
}