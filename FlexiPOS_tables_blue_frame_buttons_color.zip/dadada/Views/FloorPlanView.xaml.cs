﻿using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using Flexi2.ViewModels;

namespace Flexi2.Views
{
    public partial class FloorPlanView : UserControl
    {
        private FloorPlanViewModel? _vm;

        public FloorPlanView()
        {
            InitializeComponent();
            Loaded += (_, __) => HookViewModelAndApply();
            SizeChanged += (_, __) => ApplyLayout();
            DataContextChanged += (_, __) => HookViewModelAndApply();
        }

        private void HookViewModelAndApply()
        {
            if (_vm != null)
                _vm.Tables.CollectionChanged -= Tables_CollectionChanged;

            _vm = DataContext as FloorPlanViewModel;

            if (_vm != null)
                _vm.Tables.CollectionChanged += Tables_CollectionChanged;

            ApplyLayout();
        }

        private void Tables_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            Dispatcher.BeginInvoke(new System.Action(ApplyLayout));
        }

        private void ApplyLayout()
        {
            if (_vm == null) return;

            // Use the real visible POS area, not a fixed admin canvas.
            // The tables will stretch to the full available screen.
            _vm.ApplyFullscreenTableLayout(PosTablesControl.ActualWidth, PosTablesControl.ActualHeight);
        }
    }
}
