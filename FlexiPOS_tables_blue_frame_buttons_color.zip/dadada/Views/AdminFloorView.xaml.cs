﻿using System;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Flexi2.Models;
using Flexi2.ViewModels;

namespace Flexi2.Views
{
    public partial class AdminFloorView : UserControl
    {
        public AdminFloorView() => InitializeComponent();

        private void TableThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            table.PosX = Math.Max(0, table.PosX + e.HorizontalChange);
            table.PosY = Math.Max(0, table.PosY + e.VerticalChange);
        }

        private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            var canvas = FindParent<Canvas>(thumb);
            var minWidth = canvas != null && canvas.ActualWidth > 0
                ? Math.Max(55, canvas.ActualWidth * 0.04)
                : 55;

            var minHeight = canvas != null && canvas.ActualHeight > 0
                ? Math.Max(55, canvas.ActualHeight * 0.04)
                : 55;

            var newWidth = Math.Max(minWidth, table.Width + e.HorizontalChange);
            var newHeight = Math.Max(minHeight, table.Height + e.VerticalChange);

            // Квадрат и кръг запазват еднаква ширина и височина при разтягане/свиване.
            if (table.ShapeType == 0 || table.ShapeType == 2)
            {
                var delta = Math.Abs(e.HorizontalChange) >= Math.Abs(e.VerticalChange)
                    ? e.HorizontalChange
                    : e.VerticalChange;
                var minSide = Math.Max(minWidth, minHeight);
                var side = Math.Max(minSide, table.Width + delta);
                table.Width = side;
                table.Height = side;
            }
            else
            {
                table.Width = newWidth;
                table.Height = newHeight;
            }
        }

        private static T? FindParent<T>(System.Windows.DependencyObject child)
            where T : System.Windows.DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(child);

            while (parent != null)
            {
                if (parent is T typedParent)
                    return typedParent;

                parent = VisualTreeHelper.GetParent(parent);
            }

            return null;
        }

        private async void TableThumb_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            // Persist layout immediately when the drag ends
            if (DataContext is AdminFloorViewModel vm)
            {
                await vm.SaveTableLayoutAsync(table);
            }
        }
    }
}
