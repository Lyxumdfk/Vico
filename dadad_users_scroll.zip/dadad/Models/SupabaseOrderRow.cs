﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;

namespace Flexi2.Models
{
    [Table("orders")]
    public class SupabaseOrderRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("user_id")]
        public int UserId { get; set; }

        [Column("created_by_user_id")]
        public int? CreatedByUserId { get; set; }

        [Column("table_id")]
        public int TableId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("closed_at")]
        public DateTime? ClosedAt { get; set; }

        [Column("subtotal")]
        public decimal Subtotal { get; set; }

        [Column("discount_percent")]
        public decimal DiscountPercent { get; set; }

        [Column("discount_amount")]
        public decimal DiscountAmount { get; set; }

        [Column("tip_amount")]
        public decimal TipAmount { get; set; }

        [Column("paid_total")]
        public decimal PaidTotal { get; set; }

        [Column("payment_method")]
        public string? PaymentMethod { get; set; }

        [Column("total_price")]
        public decimal TotalPrice { get; set; }

        [Column("status")]
        public string Status { get; set; } = "open";
    }
}