﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;

namespace Flexi2.Models
{
    [Table("login_logs")]
    public class LoginLogRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public long Id { get; set; }

        [Column("user_id")]
        public int UserId { get; set; }

        [Column("username")]
        public string Username { get; set; } = string.Empty;

        [Column("role")]
        public int RoleValue { get; set; }

        [Column("login_at")]
        public DateTime LoginAt { get; set; }

        [Column("logout_at")]
        public DateTime? LogoutAt { get; set; }
    }
}