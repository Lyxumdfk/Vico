﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;

namespace Flexi2.Models
{
    public sealed class Order
    {
        public int Id { get; set; }
        public int TableId { get; set; }
        public int UserId { get; set; }
        public DateTime CreatedAtUtc { get; set; }
        public bool IsClosed { get; set; }
        public decimal DiscountPercent { get; set; }
    }
}

[Table("orders")]
public class Order : BaseModel
{
    [PrimaryKey("id", false)]
    public int Id { get; set; }

    [Column("user_id")]
    public string UserId { get; set; }

    [Column("total_price")]
    public decimal TotalPrice { get; set; }

    [Column("status")]
    public string Status { get; set; }
}

