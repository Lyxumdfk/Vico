using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;

namespace Flexi2.Models
{
    [Table("tables")]
    public class SupabaseTableLayoutRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("pos_x")]
        public double PosX { get; set; }

        [Column("pos_y")]
        public double PosY { get; set; }

        [Column("width")]
        public double Width { get; set; }

        [Column("height")]
        public double Height { get; set; }
    }
}
