using System;
using System.Collections.ObjectModel;
using Flexi2.Core.MVVM;
using Flexi2.Models;
using System.Windows;

namespace Flexi2.ViewModels
{
    public sealed class AdminMenuViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public ObservableCollection<Category> Categories { get; } = new();
        public ObservableCollection<Product> Products { get; } = new();

        private Category? _selectedCategory;
        public Category? SelectedCategory
        {
            get => _selectedCategory;
            set
            {
                _selectedCategory = value;
                OnPropertyChanged();
                LoadProducts();
            }
        }

        private Product? _selectedProduct;
        public Product? SelectedProduct
        {
            get => _selectedProduct;
            set { _selectedProduct = value; OnPropertyChanged(); }
        }

        private string _newCategoryName = "";
        public string NewCategoryName
        {
            get => _newCategoryName;
            set => SetProperty(ref _newCategoryName, value);
        }

        private string _newProductName = "";
        public string NewProductName
        {
            get => _newProductName;
            set => SetProperty(ref _newProductName, value);
        }

        private string _newProductPrice = "";
        public string NewProductPrice
        {
            get => _newProductPrice;
            set => SetProperty(ref _newProductPrice, value);
        }

        private string _error = "";
        public string Error
        {
            get => _error;
            set { _error = value; OnPropertyChanged(); }
        }

        public RelayCommand BackCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }
        public RelayCommand AddCategoryCommand { get; }
        public RelayCommand DeleteCategoryCommand { get; }
        public RelayCommand ToggleCategoryActiveCommand { get; }
        public RelayCommand AddProductCommand { get; }
        public RelayCommand DeleteProductCommand { get; }
        public RelayCommand ToggleProductActiveCommand { get; }

        public AdminMenuViewModel(MainViewModel main)
        {
            _main = main;

            BackCommand = new RelayCommand(_ => _main.Nav.NavigateTo(new AdminViewModel(_main)));

            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            // ✅ REALTIME FIX (ВАЖНО)
            _main.Realtime.TableChanged += table =>
            {
                if (table == "categories" || table == "products")
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var keepCategoryId = SelectedCategory?.Id;

                        LoadCategories();

                        if (keepCategoryId != null)
                        {
                            foreach (var c in Categories)
                            {
                                if (c.Id == keepCategoryId)
                                {
                                    SelectedCategory = c;
                                    break;
                                }
                            }
                        }

                        LoadProducts();
                    });
                }
            };

            AddCategoryCommand = new RelayCommand(_ =>
            {
                try
                {
                    Error = "";
                    var name = (NewCategoryName ?? "").Trim();
                    if (name.Length < 2) { Error = "Името е твърде кратко."; return; }

                    _main.MenuRepo.AddCategory(name);
                    NewCategoryName = "";
                    LoadCategories(true);
                }
                catch (Exception ex)
                {
                    Error = ex.Message;
                }
            });

            DeleteCategoryCommand = new RelayCommand(_ =>
            {
                if (SelectedCategory == null) return;
                _main.MenuRepo.DeleteCategory(SelectedCategory.Id);
                LoadCategories();
            });

            ToggleCategoryActiveCommand = new RelayCommand(_ =>
            {
                if (SelectedCategory == null) return;
                _main.MenuRepo.SetCategoryActive(SelectedCategory.Id, !SelectedCategory.IsActive);
                LoadCategories();
            });

            AddProductCommand = new RelayCommand(_ =>
            {
                if (SelectedCategory == null) return;

                if (!decimal.TryParse(NewProductPrice.Replace(',', '.'), System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out var price))
                {
                    Error = "Невалидна цена";
                    return;
                }

                _main.MenuRepo.AddProduct(SelectedCategory.Id, NewProductName, price, false);
                NewProductName = "";
                NewProductPrice = "";
                LoadProducts(true);
            });

            DeleteProductCommand = new RelayCommand(p =>
            {
                var pr = p as Product ?? SelectedProduct;
                if (pr == null) return;
                _main.MenuRepo.DeleteProduct(pr.Id);
                LoadProducts();
            });

            ToggleProductActiveCommand = new RelayCommand(p =>
            {
                var pr = p as Product ?? SelectedProduct;
                if (pr == null) return;
                _main.MenuRepo.SetProductActive(pr.Id, !pr.IsActive);
                LoadProducts();
            });

            LoadCategories();
        }

        private void LoadCategories(bool selectLast = false)
        {
            Categories.Clear();
            foreach (var c in _main.MenuRepo.GetCategories(true))
                Categories.Add(c);

            if (Categories.Count == 0)
            {
                SelectedCategory = null;
                Products.Clear();
                return;
            }

            SelectedCategory = selectLast ? Categories[^1] : Categories[0];
        }

        private void LoadProducts(bool selectLast = false)
        {
            Products.Clear();
            if (SelectedCategory == null) return;

            foreach (var p in _main.MenuRepo.GetProducts(SelectedCategory.Id, true))
                Products.Add(p);

            if (selectLast && Products.Count > 0)
                SelectedProduct = Products[^1];
        }
    }
}