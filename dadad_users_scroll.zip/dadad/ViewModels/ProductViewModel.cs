﻿using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;

namespace Flexi2.ViewModels
{
    public sealed class ProductViewModel : ObservableObject
    {
        private readonly MainViewModel _main;
        private readonly TicketViewModel _ticket;

        public int TableId { get; }
        public Category Category { get; }

        public ObservableCollection<Product> Products { get; } = new();

        private string _newName = "";
        public string NewName
        {
            get => _newName;
            set => Set(ref _newName, value);
        }

        private string _newPriceText = "";
        public string NewPriceText
        {
            get => _newPriceText;
            set => Set(ref _newPriceText, value);
        }

        private string _newCategory = "";
        public string NewCategory
        {
            get => _newCategory;
            set => Set(ref _newCategory, value);
        }

        private string _error = "";
        public string Error
        {
            get => _error;
            set => Set(ref _error, value);
        }

        public RelayCommand BackToCategoriesCommand { get; }
        public RelayCommand BackToTicketCommand { get; }
        public RelayCommand AddProductCommand { get; }
        public RelayCommand AddCommand { get; }

        public ProductViewModel(MainViewModel main, int tableId, Category category, TicketViewModel ticket)
        {
            _main = main;
            TableId = tableId;
            Category = category;
            _ticket = ticket;

            NewCategory = string.IsNullOrWhiteSpace(category.Name) ? "Без категория" : category.Name;

            BackToCategoriesCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new CategoryViewModel(_main, tableId, _ticket)));

            BackToTicketCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(_ticket));

            AddProductCommand = new RelayCommand(p =>
            {
                if (p is not Product pr) return;
                _ticket.AddDraftProduct(pr);
            });

            AddCommand = new RelayCommand(async _ => await AddProductAsync());

            Load();
        }

        private void Load()
        {
            Products.Clear();

            foreach (var p in _main.MenuRepo.GetProducts(Category.Id))
                Products.Add(p);
        }


        private async Task AddProductAsync()
        {
            try
            {
                Error = "";

                var name = (NewName ?? "").Trim();
                if (name.Length == 0)
                {
                    Error = "Въведи име";
                    return;
                }

                if (!decimal.TryParse(
                    (NewPriceText ?? "").Trim().Replace(',', '.'),
                    System.Globalization.NumberStyles.Number,
                    System.Globalization.CultureInfo.InvariantCulture,
                    out var price))
                {
                    Error = "Невалидна цена";
                    return;
                }

                var categoryName = string.IsNullOrWhiteSpace(NewCategory)
                    ? (string.IsNullOrWhiteSpace(Category.Name) ? "Без категория" : Category.Name)
                    : NewCategory.Trim();

                // локално
                var localId = _main.MenuRepo.AddProduct(Category.Id, name, price, false);

                Products.Add(new Product
                {
                    Id = localId,
                    CategoryId = Category.Id,
                    Name = name,
                    Price = price,
                    IsActive = true,
                    HasModifiers = false
                });

                // supabase
                await App.SupabaseClient
                    .From<Flexi2.Models.ProductRow>()
                    .Insert(new Flexi2.Models.ProductRow
                    {
                        Name = name,
                        Price = price,
                        Category = categoryName,
                        CategoryId = Category.Id,
                        HasModifiers = false,
                        IsActive = true
                    });

                NewName = "";
                NewPriceText = "";
                NewCategory = Category.Name ?? "Без категория";
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                System.Windows.MessageBox.Show(ex.ToString(), "AddProduct грешка");
            }
        }
    
    }
}