using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Flexi2.ViewModels
{
    public sealed class TicketViewModel : ObservableObject
    {
        private readonly MainViewModel _main;
        public int TableId { get; }

        public ObservableCollection<OrderItem> LockedItems { get; } = new();
        public ObservableCollection<OrderItem> DraftItems { get; } = new();

        private string _title = "";
        public string Title
        {
            get => _title;
            set => Set(ref _title, value);
        }

        private decimal _total;
        public decimal Total
        {
            get => _total;
            set => Set(ref _total, value);
        }

        private string _error = "";
        public string Error
        {
            get => _error;
            set => Set(ref _error, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set => Set(ref _isBusy, value);
        }

        public RelayCommand BackToFloorCommand { get; }
        public RelayCommand AddItemsCommand { get; }
        public RelayCommand IncDraftCommand { get; }
        public RelayCommand DecDraftCommand { get; }
        public RelayCommand PlaceOrderCommand { get; }
        public RelayCommand CloseBillCommand { get; }

        public TicketViewModel(MainViewModel main, int tableId)
        {
            _main = main;
            TableId = tableId;

            Error = "";

            BackToFloorCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new FloorPlanViewModel(_main)));

            AddItemsCommand = new RelayCommand(_ =>
                _main.Nav.NavigateTo(new CategoryViewModel(_main, tableId, this)));

            IncDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;
                it.Qty++;
                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            DecDraftCommand = new RelayCommand(o =>
            {
                if (o is not OrderItem it) return;

                if (it.Qty > 1)
                    it.Qty--;
                else
                    DraftItems.Remove(it);

                Recalc();
                PlaceOrderCommand.RaiseCanExecuteChanged();
            });

            PlaceOrderCommand = new RelayCommand(async _ => await PlaceOrderAsync(), _ => DraftItems.Count > 0 && !IsBusy);

            CloseBillCommand = new RelayCommand(_ =>
            {
                if (IsBusy) return;
                _main.Nav.NavigateTo(new PaymentViewModel(_main, this));
            });

            _ = LoadAsync();
        }

        public void AddDraftProduct(Product p)
        {
            var existing = DraftItems.FirstOrDefault(x => x.ProductId == p.Id && x.ProductName == p.Name);

            if (existing != null)
            {
                existing.Qty++;
            }
            else
            {
                DraftItems.Add(new OrderItem
                {
                    ProductId = p.Id,
                    ProductName = p.Name,
                    UnitPrice = p.Price,
                    Qty = 1,
                    IsLocked = false
                });
            }

            Recalc();
            PlaceOrderCommand.RaiseCanExecuteChanged();
        }

        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var lockedItems = await _main.PosService.GetOpenOrderItemsByTable(TableId);

                var total = lockedItems.Sum(i => i.UnitPrice * i.Qty)
                            + DraftItems.Sum(i => i.UnitPrice * i.Qty);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    LockedItems.Clear();
                    foreach (var it in lockedItems)
                        LockedItems.Add(it);

                    Title = $"Сметка • Маса #{TableId}";
                    Total = total;
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }

        private void Recalc()
        {
            var locked = LockedItems.Sum(i => i.UnitPrice * i.Qty);
            var draft = DraftItems.Sum(i => i.UnitPrice * i.Qty);
            Total = locked + draft;
        }

        private async Task PlaceOrderAsync()
        {
            try
            {
                IsBusy = true;
                Error = "";

                var user = _main.Session.CurrentUser;
                if (user == null)
                {
                    Error = "Няма активен потребител.";
                    return;
                }

                var draftCopy = DraftItems.Select(d => new OrderItem
                {
                    ProductId = d.ProductId,
                    ProductName = d.ProductName,
                    UnitPrice = d.UnitPrice,
                    Qty = d.Qty,
                    IsLocked = true
                }).ToList();

                await _main.PosService.PlaceOrderAsync(TableId, user.Id, draftCopy);               

                Application.Current.Dispatcher.Invoke(() =>
                {
                    DraftItems.Clear();
                    PlaceOrderCommand.RaiseCanExecuteChanged();
                });

                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
                PlaceOrderCommand.RaiseCanExecuteChanged();
            }
        }
    }
}