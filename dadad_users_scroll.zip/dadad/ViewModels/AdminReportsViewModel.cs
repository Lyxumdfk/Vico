using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Flexi2.Core.MVVM;
using Flexi2.Models;
using System.Windows;
using System.Windows.Threading;

namespace Flexi2.ViewModels
{
    public sealed class AdminReportsViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public ObservableCollection<TurnoverEntry> Entries { get; } = new();

        private decimal _total;
        public decimal Total { get => _total; set => Set(ref _total, value); }

        private string _rangeLabel = "";
        public string RangeLabel { get => _rangeLabel; set => Set(ref _rangeLabel, value); }

        private string _error = "";
        public string Error { get => _error; set => Set(ref _error, value); }

        private bool _isBusy;
        public bool IsBusy { get => _isBusy; set => Set(ref _isBusy, value); }

        private (DateTime fromUtc, DateTime toUtc, string label) _currentRange;
        private readonly DispatcherTimer _refreshTimer;

        public RelayCommand TodayCommand { get; }
        public RelayCommand WeekCommand { get; }
        public RelayCommand MonthCommand { get; }
        public RelayCommand YearCommand { get; }
        public RelayCommand BackCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }

        public AdminReportsViewModel(MainViewModel main)
        {
            _main = main;

            TodayCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeToday()));
            WeekCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeWeek()));
            MonthCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeMonth()));
            YearCommand = new RelayCommand(async _ => await LoadRangeAsync(RangeYear()));
            BackCommand = new RelayCommand(_ => _main.Nav.NavigateTo(new AdminViewModel(_main)));
            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            _currentRange = RangeToday();
            _ = LoadRangeAsync(_currentRange);

            // Realtime refresh: Supabase понякога праща събитието малко преди update-ът да се вижда напълно.
            // Затова презареждаме веднага и още веднъж след кратко забавяне.
            _main.Realtime.TableChanged += table =>
            {
                if (table == "orders" || table == "order_items" || table == "users" || table == "products")
                {
                    Application.Current.Dispatcher.Invoke(async () =>
                    {
                        await LoadRangeAsync(_currentRange);
                        await Task.Delay(700);
                        await LoadRangeAsync(_currentRange);
                    });
                }
            };

            // Резервно автоматично обновяване, ако Realtime каналът изпусне събитие.
            _refreshTimer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(3)
            };
            _refreshTimer.Tick += async (_, __) => await LoadRangeAsync(_currentRange);
            _refreshTimer.Start();
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeToday()
        {
            var startLocal = DateTime.Now.Date;
            var endLocal = startLocal.AddDays(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Днес ({startLocal:dd.MM.yyyy})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeWeek()
        {
            var now = DateTime.Now;
            var diff = ((int)now.DayOfWeek + 6) % 7;
            var startLocal = now.Date.AddDays(-diff);
            var endLocal = startLocal.AddDays(7);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Седмица ({startLocal:dd.MM} - {endLocal.AddDays(-1):dd.MM})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeMonth()
        {
            var now = DateTime.Now;
            var startLocal = new DateTime(now.Year, now.Month, 1);
            var endLocal = startLocal.AddMonths(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Месец ({startLocal:MMMM yyyy})");
        }

        private static (DateTime fromUtc, DateTime toUtc, string label) RangeYear()
        {
            var now = DateTime.Now;
            var startLocal = new DateTime(now.Year, 1, 1);
            var endLocal = startLocal.AddYears(1);
            return (startLocal.ToUniversalTime(), endLocal.ToUniversalTime(), $"Година ({startLocal:yyyy})");
        }

        private async Task LoadRangeAsync((DateTime fromUtc, DateTime toUtc, string label) range)
        {
            try
            {
                IsBusy = true;
                Error = "";
                _currentRange = range;
                RangeLabel = range.label;

                var entries = await _main.ReportsRepo.GetTurnoverEntriesAsync(range.fromUtc, range.toUtc);

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Entries.Clear();
                    foreach (var e in entries)
                        Entries.Add(e);

                    Total = 0;
                    foreach (var e in Entries)
                        Total += e.TotalAfterDiscount;
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                Total = 0;
                Entries.Clear();
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}
