using Flexi2.Core.MVVM;
using Flexi2.Models;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows;

namespace Flexi2.ViewModels
{
    public sealed class AdminFloorViewModel : ObservableObject
    {
        private readonly MainViewModel _main;

        public ObservableCollection<ZoneModel> Zones { get; } = new();
        public ObservableCollection<TableModel> Tables { get; } = new();

        private TableModel? _selectedTable;
        public TableModel? SelectedTable
        {
            get => _selectedTable;
            set => SetProperty(ref _selectedTable, value);
        }

        private ZoneModel? _selectedZone;
        public ZoneModel? SelectedZone
        {
            get => _selectedZone;
            set
            {
                if (SetProperty(ref _selectedZone, value))
                    ReloadTables();
            }
        }

        private string _newZoneName = string.Empty;
        public string NewZoneName
        {
            get => _newZoneName;
            set => SetProperty(ref _newZoneName, value);
        }

        private string _newTableName = string.Empty;
        public string NewTableName
        {
            get => _newTableName;
            set => SetProperty(ref _newTableName, value);
        }

        private string _error = string.Empty;
        public string Error
        {
            get => _error;
            set => SetProperty(ref _error, value);
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                    System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            }
        }

        public RelayCommand BackCommand { get; }
        public RelayCommand BackToActivitiesCommand { get; }
        public RelayCommand RefreshCommand { get; }

        public RelayCommand AddZoneCommand { get; }
        public RelayCommand DeleteZoneCommand { get; }
        public RelayCommand AddTableCommand { get; }
        public RelayCommand DeleteTableCommand { get; }

        public AdminFloorViewModel(MainViewModel main)
        {
            _main = main;

            BackCommand = new RelayCommand(_ => _main.Nav.NavigateTo(new AdminViewModel(_main)));
            BackToActivitiesCommand = new RelayCommand(_ =>
            {
                _main.Session.Logout();
                _main.Nav.NavigateTo(new LoginViewModel(_main));
            });

            RefreshCommand = new RelayCommand(async _ => await LoadAsync());
            AddZoneCommand = new RelayCommand(async _ => await AddZoneAsync());
            DeleteZoneCommand = new RelayCommand(async _ => await DeleteZoneAsync());
            AddTableCommand = new RelayCommand(async _ => await AddTableAsync());
            DeleteTableCommand = new RelayCommand(async t => await DeleteTableAsync(t as TableModel));

            _ = LoadAsync();

            _main.Realtime.TableChanged += table =>
            {
                if (table == "zones" || table == "tables" || table == "orders" || table == "order_items")
                {
                    Application.Current.Dispatcher.Invoke(() =>
                    {
                        var keepZoneId = SelectedZone?.Id;
                        _ = LoadAsync();

                        if (keepZoneId != null)
                        {
                            foreach (var z in Zones)
                            {
                                if (z.Id == keepZoneId)
                                {
                                    SelectedZone = z;
                                    break;
                                }
                            }
                        }
                    });
                }
            };

        }


        private async Task LoadAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                var zones = await Task.Run(() => _main.FloorRepo.GetZones());

                Application.Current.Dispatcher.Invoke(() =>
                {
                    Zones.Clear();
                    foreach (var z in zones)
                        Zones.Add(z);

                    SelectedZone ??= Zones.Count > 0 ? Zones[0] : null;
                    ReloadTables();
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private void ReloadTables()
        {
            Tables.Clear();
            if (SelectedZone?.Tables == null) return;

            foreach (var t in SelectedZone.Tables)
                Tables.Add(t);

            SelectedTable = Tables.Count > 0 ? Tables[0] : null;
        }

        public async Task SaveTableLayoutAsync(TableModel table)
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                await Task.Run(() =>
                    _main.FloorRepo.UpdateTableLayout(table.Id, table.PosX, table.PosY, table.Width, table.Height));
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task AddZoneAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                var name = (NewZoneName ?? string.Empty).Trim();
                if (name.Length == 0)
                {
                    Error = "Въведи име на зона.";
                    return;
                }

                await Task.Run(() => _main.FloorRepo.AddZone(name));

                NewZoneName = string.Empty;
                await LoadAsync();

                foreach (var z in Zones)
                {
                    if (string.Equals(z.Name, name, StringComparison.OrdinalIgnoreCase))
                    {
                        SelectedZone = z;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task DeleteZoneAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (SelectedZone == null)
                {
                    Error = "Избери зона.";
                    return;
                }

                var zoneId = SelectedZone.Id;

                await Task.Run(() => _main.FloorRepo.DeleteZone(zoneId));

                SelectedZone = null;
                await LoadAsync();
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task AddTableAsync()
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (SelectedZone == null)
                {
                    Error = "Избери зона.";
                    return;
                }

                var zoneId = SelectedZone.Id;
                var name = (NewTableName ?? string.Empty).Trim();

                if (name.Length == 0)
                {
                    Error = "Въведи име на маса.";
                    return;
                }

                await Task.Run(() => _main.FloorRepo.AddTable(zoneId, name));

                NewTableName = string.Empty;

                await LoadAsync();

                foreach (var z in Zones)
                    if (z.Id == zoneId)
                    {
                        SelectedZone = z;
                        break;
                    }
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }

        private async Task DeleteTableAsync(TableModel? table)
        {
            try
            {
                IsBusy = true;
                Error = string.Empty;

                if (table == null)
                {
                    Error = "Избери маса.";
                    return;
                }

                var keepZoneId = SelectedZone?.Id;

                await Task.Run(() => _main.FloorRepo.DeleteTable(table.Id));

                await LoadAsync();

                if (keepZoneId != null)
                    foreach (var z in Zones)
                        if (z.Id == keepZoneId)
                        {
                            SelectedZone = z;
                            break;
                        }
            }
            catch (Exception ex)
            {
                Error = ex.Message;
            }
            finally
            {
                IsBusy = false;
            }
        }
    }
}