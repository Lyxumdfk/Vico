﻿using Supabase;
using Supabase.Realtime;
using Supabase.Realtime.PostgresChanges;
using System;
using System.Threading.Tasks;
using static Supabase.Realtime.PostgresChanges.PostgresChangesOptions;

namespace Flexi2.Services
{
    public sealed class SupabaseRealtimeService
    {
        private const string SupabaseUrl = "https://piyhpiiqmphtrrwqjgbn.supabase.co";
        private const string SupabaseAnonKey = "sb_publishable_OapgbUIscS0DkYU00FS3gg_EHXJ6KgF";

        private readonly Supabase.Client _client;
        private bool _started;

        public event Action<string>? TableChanged;

        public SupabaseRealtimeService()
        {
            var options = new SupabaseOptions
            {
                AutoConnectRealtime = true
            };

            _client = new Supabase.Client(SupabaseUrl, SupabaseAnonKey, options);
        }

        public async Task StartAsync()
        {
            if (_started) return;
            _started = true;

            await _client.InitializeAsync();

            await WatchTable("users");
            await WatchTable("zones");
            await WatchTable("tables");
            await WatchTable("categories");
            await WatchTable("products");
            await WatchTable("orders");
            await WatchTable("order_items");
        }

        private async Task WatchTable(string tableName)
        {
            var channel = _client.Realtime.Channel($"public-{tableName}-{Guid.NewGuid():N}");

            channel.Register(new PostgresChangesOptions("public", tableName));

            channel.AddPostgresChangeHandler(ListenType.All, (sender, change) =>
            {
                TableChanged?.Invoke(tableName);
            });

            await channel.Subscribe();
        }
    }
}