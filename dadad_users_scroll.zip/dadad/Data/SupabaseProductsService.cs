﻿using Flexi2.Models;
using System.Linq;
using System.Threading.Tasks;

namespace Flexi2.Data
{
    public sealed class SupabaseProductsService
    {
        public async Task<Product?> AddAsync(string name, decimal price, string category)
        {
            var row = new ProductRow
            {
                Name = name.Trim(),
                Price = price,
                Category = string.IsNullOrWhiteSpace(category) ? "Без категория" : category.Trim(),
                CategoryId = 0,
                HasModifiers = false,
                IsActive = true
            };

            var inserted = await App.SupabaseClient
                .From<ProductRow>()
                .Insert(row);

            var p = inserted.Models.FirstOrDefault();
            if (p == null) return null;

            return new Product
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price,
                Category = p.Category,
                CategoryId = p.CategoryId,
                HasModifiers = p.HasModifiers,
                IsActive = p.IsActive
            };
        }
    }
}