using Flexi2.Models;
using Supabase.Realtime.PostgresChanges;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using static Supabase.Postgrest.Constants;
using static Supabase.Realtime.PostgresChanges.PostgresChangesOptions;

namespace Flexi2.Data
{
    public sealed class SupabasePosService
    {
        public async Task<long> LogLoginAsync(User user)
        {
            var row = new LoginLogRow
            {
                UserId = user.Id,
                Username = user.Name,
                RoleValue = user.RoleValue,
                LoginAt = DateTime.UtcNow
            };

            var result = await App.SupabaseClient
                .From<LoginLogRow>()
                .Insert(row);

            return result.Models.First().Id;
        }

        public async Task LogLogoutAsync(long loginLogId)
        {
            await App.SupabaseClient
                .From<LoginLogRow>()
                .Filter("id", Operator.Equals, loginLogId.ToString())
                .Set(x => x.LogoutAt, DateTime.UtcNow)
                .Update();
        }

        public async Task<SupabaseOrderRow> EnsureOpenOrderAsync(int tableId, int userId)
        {
            var existing = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("table_id", Operator.Equals, tableId.ToString())
                .Filter("status", Operator.Equals, "open")
                .Get();

            var open = existing.Models
                .OrderByDescending(x => x.Id)
                .FirstOrDefault();

            if (open != null)
                return open;

            var newOrder = new SupabaseOrderRow
            {
                UserId = userId,
                CreatedByUserId = userId,
                TableId = tableId,
                CreatedAt = DateTime.UtcNow,
                Status = "open",
                TotalPrice = 0,
                Subtotal = 0,
                PaidTotal = 0
            };

            var inserted = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Insert(newOrder);

            return inserted.Models.First();
        }

        public async Task AddItemsAsync(int orderId, int userId, IEnumerable<OrderItem> items)
        {
            var rows = items.Select(x => new SupabaseOrderItemRow
            {
                OrderId = orderId,
                ProductId = x.ProductId,
                ProductName = x.ProductName,
                Quantity = x.Qty,
                Price = x.UnitPrice,
                OrderedAt = DateTime.UtcNow,
                OrderedByUserId = userId
            }).ToList();

            if (rows.Count == 0)
                return;

            await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Insert(rows);

            await RefreshOrderTotalAsync(orderId);
        }

        public async Task<decimal> GetOpenOrderTotalAsync(int orderId)
        {
            var items = await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Filter("order_id", Operator.Equals, orderId.ToString())
                .Get();

            return items.Models.Sum(x => x.Price * x.Quantity);
        }

        public async Task<List<OrderItem>> GetOpenOrderItemsByTable(int tableId)
        {
            var openOrder = await GetLatestOpenOrderByTableAsync(tableId);
            if (openOrder == null)
                return new List<OrderItem>();

            var items = await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .Filter("order_id", Operator.Equals, openOrder.Id.ToString())
                .Get();

            return items.Models
                .OrderBy(x => x.Id)
                .Select(x => new OrderItem
                {
                    Id = x.Id,
                    OrderId = x.OrderId,
                    ProductId = x.ProductId,
                    ProductName = x.ProductName,
                    UnitPrice = x.Price,
                    Qty = x.Quantity,
                    IsLocked = true
                })
                .ToList();
        }

        public async Task RefreshOrderTotalAsync(int orderId)
        {
            var total = await GetOpenOrderTotalAsync(orderId);

            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, orderId.ToString())
                .Set(x => x.Subtotal, total)
                .Set(x => x.TotalPrice, total)
                .Update();
        }

        public async Task CloseOrderAsync(int tableId, string paymentMethod, decimal discountPercent, decimal tipAmount)
        {
            var openOrder = await GetLatestOpenOrderByTableAsync(tableId);
            if (openOrder == null)
                return;

            var subtotal = await GetOpenOrderTotalAsync(openOrder.Id);

            if (discountPercent < 0) discountPercent = 0;
            if (discountPercent > 100) discountPercent = 100;
            if (tipAmount < 0) tipAmount = 0;

            var discountAmount = subtotal * (discountPercent / 100m);
            var finalTotal = (subtotal - discountAmount) + tipAmount;

            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, openOrder.Id.ToString())
                .Set(x => x.Subtotal, subtotal)
                .Set(x => x.DiscountPercent, discountPercent)
                .Set(x => x.DiscountAmount, discountAmount)
                .Set(x => x.TipAmount, tipAmount)
                .Set(x => x.PaidTotal, finalTotal)
                .Set(x => x.TotalPrice, finalTotal)
                .Set(x => x.PaymentMethod!, paymentMethod)
                .Set(x => x.Status!, "paid")
                .Set(x => x.ClosedAt, DateTime.UtcNow)
                .Update();

            var tableResult = await App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Operator.Equals, tableId.ToString())
                .Get();

            var table = tableResult.Models.FirstOrDefault();
            if (table != null)
            {
                table.Status = 0;
                table.OwnerUserId = null;
                table.OpenedAtUtc = null;
                table.CurrentTotal = 0m;

                await App.SupabaseClient
                    .From<SupabaseTableRow>()
                    .Update(table);
            }
        }

        public async Task<SupabaseOrderRow?> GetLatestOpenOrderByTableAsync(int tableId)
        {
            var result = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("table_id", Operator.Equals, tableId.ToString())
                .Filter("status", Operator.Equals, "open")
                .Get();

            return result.Models
                .OrderByDescending(x => x.Id)
                .FirstOrDefault();
        }

        public async Task StartRealtimeAsync(Action onOrdersChanged, Action onLoginsChanged)
        {
            await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onOrdersChanged);
                });

            await App.SupabaseClient
                .From<SupabaseOrderItemRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onOrdersChanged);
                });

            await App.SupabaseClient
                .From<LoginLogRow>()
                .On(ListenType.All, (sender, change) =>
                {
                    Application.Current.Dispatcher.Invoke(onLoginsChanged);
                });
        }

        public async Task PlaceOrderAsync(int tableId, int userId, List<OrderItem> items)
        {
            if (items == null || items.Count == 0)
                return;

            var order = await EnsureOpenOrderAsync(tableId, userId);

            await AddItemsAsync(order.Id, userId, items);

            var refreshedOrder = await App.SupabaseClient
                .From<SupabaseOrderRow>()
                .Filter("id", Operator.Equals, order.Id.ToString())
                .Get();

            var latestOrder = refreshedOrder.Models.FirstOrDefault();
            var total = latestOrder?.TotalPrice ?? 0m;

            var tableResult = await App.SupabaseClient
                .From<SupabaseTableRow>()
                .Filter("id", Operator.Equals, tableId.ToString())
                .Get();

            var table = tableResult.Models.FirstOrDefault();
            if (table != null)
            {
                table.Status = 1;
                table.OwnerUserId = userId;
                table.OpenedAtUtc = DateTime.UtcNow.ToString("O");
                table.CurrentTotal = total;

                await App.SupabaseClient
                    .From<SupabaseTableRow>()
                    .Update(table);
            }
        }
    }
}