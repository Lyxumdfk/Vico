﻿using Flexi2.Core.Security;
using Flexi2.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace Flexi2.Data
{
    public sealed class UserRepository
    {
        private readonly FlexiDb _db;

        public UserRepository(FlexiDb db) => _db = db;

        public async Task<User?> TryLoginByPinAsync(string pin, UserRole role)
        {
            pin = (pin ?? "").Trim();
            if (pin.Length == 0) return null;

            var response = await App.SupabaseClient
                .From<User>()
                .Filter("role", Supabase.Postgrest.Constants.Operator.Equals, ((int)role).ToString())
                .Filter("isactive", Supabase.Postgrest.Constants.Operator.Equals, "true")
                .Get();

            foreach (var u in response.Models)
            {
                // 1) Новият вариант от Flutter: pin_code
                // За да работи това, в User.cs и UserRow.cs трябва да имаш property PinCode с [Column("pin_code")]
                if (!string.IsNullOrWhiteSpace(u.PinCode) && u.PinCode.Trim() == pin)
                    return u;

                // 2) Старият вариант от WPF: pinhash + pinsalt
                if (!string.IsNullOrWhiteSpace(u.PinSalt) &&
                    !string.IsNullOrWhiteSpace(u.PinHash) &&
                    PinHasher.Verify(pin, u.PinSalt, u.PinHash))
                    return u;
            }

            return null;
        }

        public async Task<List<User>> GetAllAsync()
        {
            var response = await App.SupabaseClient
                .From<User>()
                .Get();

            return response.Models
                .OrderByDescending(x => x.RoleValue)
                .ThenBy(x => x.Name)
                .ToList();
        }

        public void Create(string name, UserRole role, string pin)
        {
            name = (name ?? "").Trim();
            pin = (pin ?? "").Trim();
            if (name.Length == 0 || pin.Length == 0) return;

            var salt = PinHasher.NewSaltHex();
            var hash = PinHasher.Hash(pin, salt);

            var user = new UserRow
            {
                Name = name,
                PinCode = pin,
                PinHash = hash,
                PinSalt = salt,
                RoleValue = (int)role,
                IsActive = true
            };

            App.SupabaseClient
                .From<UserRow>()
                .Insert(user)
                .GetAwaiter()
                .GetResult();
        }

        public void UpdateNameRole(int id, string name, UserRole role, bool isActive)
        {
            name = (name ?? "").Trim();
            if (name.Length == 0) return;

            App.SupabaseClient
                .From<UserRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, id.ToString())
                .Set(x => x.Name!, name)
                .Set(x => x.RoleValue, (int)role)
                .Set(x => x.IsActive, isActive)
                .Update()
                .GetAwaiter()
                .GetResult();
        }

        public void ChangePin(int id, string newPin)
        {
            newPin = (newPin ?? "").Trim();
            if (newPin.Length == 0) return;

            var salt = PinHasher.NewSaltHex();
            var hash = PinHasher.Hash(newPin, salt);

            App.SupabaseClient
                .From<UserRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, id.ToString())
                .Set(x => x.PinCode!, newPin)
                .Set(x => x.PinHash!, hash)
                .Set(x => x.PinSalt!, salt)
                .Update()
                .GetAwaiter()
                .GetResult();
        }

        public void Delete(int id)
        {
            App.SupabaseClient
                .From<UserRow>()
                .Filter("id", Supabase.Postgrest.Constants.Operator.Equals, id.ToString())
                .Delete()
                .GetAwaiter()
                .GetResult();
        }
    }
}
