-- Run this once in Supabase SQL Editor if you want table shapes
-- (Circle/Square/Rectangle) to stay saved after refresh/restart.
alter table public.tables
add column if not exists shape text not null default 'Rectangle';
