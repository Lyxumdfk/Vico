﻿using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using Flexi2.ViewModels;

namespace Flexi2.Views
{
    public partial class FloorPlanView : UserControl
    {
        private FloorPlanViewModel? _vm;

        public FloorPlanView()
        {
            InitializeComponent();
            Loaded += (_, __) => HookViewModelAndApply();
            SizeChanged += (_, __) => ApplyLayout();
            DataContextChanged += (_, __) => HookViewModelAndApply();
        }

        private void HookViewModelAndApply()
        {
            if (_vm != null)
                _vm.Tables.CollectionChanged -= Tables_CollectionChanged;

            _vm = DataContext as FloorPlanViewModel;

            if (_vm != null)
                _vm.Tables.CollectionChanged += Tables_CollectionChanged;

            ApplyLayout();
        }

        private void Tables_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            Dispatcher.BeginInvoke(new System.Action(ApplyLayout));
        }

        private void ApplyLayout()
        {
            if (_vm == null) return;

            // Do not rely on the generated x:Name field here. Some project copies
            // had the XAML name out of sync and Visual Studio failed with
            // "PosTablesControl does not exist in the current context".
            var tablesControl = FindName("PosTablesControl") as FrameworkElement;
            var width = tablesControl?.ActualWidth ?? ActualWidth;
            var height = tablesControl?.ActualHeight ?? ActualHeight;

            if (width <= 1 || height <= 1)
                return;

            _vm.ApplyFullscreenTableLayout(width, height);
        }
    }
}
