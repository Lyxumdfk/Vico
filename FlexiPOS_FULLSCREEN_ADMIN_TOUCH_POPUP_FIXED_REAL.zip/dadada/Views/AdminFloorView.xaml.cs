﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Flexi2.Models;
using Flexi2.ViewModels;

namespace Flexi2.Views
{
    public partial class AdminFloorView : UserControl
    {
        private double _scaleX = 1.0;
        private double _scaleY = 1.0;
        private AdminFloorViewModel? _subscribedVm;

        public AdminFloorView()
        {
            InitializeComponent();
            Loaded += (_, _) => ApplyAdaptiveAdminLayout();
            DataContextChanged += (_, _) => SubscribeToTablesCollection();
        }

        private void SubscribeToTablesCollection()
        {
            if (_subscribedVm != null)
                _subscribedVm.Tables.CollectionChanged -= Tables_CollectionChanged;

            _subscribedVm = DataContext as AdminFloorViewModel;

            if (_subscribedVm != null)
                _subscribedVm.Tables.CollectionChanged += Tables_CollectionChanged;

            Dispatcher.BeginInvoke(new Action(ApplyAdaptiveAdminLayout));
        }

        private void Tables_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
            => Dispatcher.BeginInvoke(new Action(ApplyAdaptiveAdminLayout));

        private void AdminTablesControl_Loaded(object sender, RoutedEventArgs e)
            => ApplyAdaptiveAdminLayout();

        private void AdminTablesControl_SizeChanged(object sender, SizeChangedEventArgs e)
            => ApplyAdaptiveAdminLayout();

        private void ApplyAdaptiveAdminLayout()
        {
            if (DataContext is not AdminFloorViewModel vm || vm.Tables.Count == 0)
                return;

            // Admin canvas трябва да е използваем от самия ляв край.
            // Без safe padding, за да можеш да сложиш маса на X=0.
            const double safePadding = 0.0;
            var tablesControl = FindName("AdminTablesControl") as FrameworkElement;
            double availableWidth = Math.Max(1, (tablesControl?.ActualWidth ?? ActualWidth));
            double availableHeight = Math.Max(1, (tablesControl?.ActualHeight ?? ActualHeight));

            if (availableWidth <= 0 || availableHeight <= 0)
                return;

            // В Admin НЕ нормализираме по minX/minY.
            // Предишният вариант изваждаше minX/minY и когато местиш една маса,
            // тя постоянно се залепяше/смачкваше визуално в горния ляв край.
            // Тук ползваме реалните PosX/PosY, за да можеш спокойно да влачиш масата.
            double maxRight = vm.Tables.Max(t => t.PosX + t.Width);
            double maxBottom = vm.Tables.Max(t => t.PosY + t.Height);
            double layoutWidth = Math.Max(1, maxRight);
            double layoutHeight = Math.Max(1, maxBottom);

            // Не уголемяваме малки layout-и. Само свиваме, ако излязат извън работното поле.
            double scale = Math.Min(1.0, Math.Min(availableWidth / layoutWidth, availableHeight / layoutHeight));
            _scaleX = scale;
            _scaleY = scale;

            foreach (var table in vm.Tables)
            {
                table.DisplayPosX = Math.Max(0, table.PosX * scale);
                table.DisplayPosY = Math.Max(0, table.PosY * scale);
                table.DisplayWidth = Math.Max(55, table.Width * scale);
                table.DisplayHeight = Math.Max(55, table.Height * scale);
            }
        }

        private void TableThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;

            var canvas = FindParent<Canvas>(thumb);
            var maxX = canvas != null && canvas.ActualWidth > 0
                ? Math.Max(0, (canvas.ActualWidth / sx) - table.Width)
                : 2000;
            var maxY = canvas != null && canvas.ActualHeight > 0
                ? Math.Max(0, (canvas.ActualHeight / sy) - table.Height)
                : 1200;

            table.PosX = Math.Max(0, Math.Min(maxX, table.PosX + (e.HorizontalChange / sx)));
            table.PosY = Math.Max(0, Math.Min(maxY, table.PosY + (e.VerticalChange / sy)));

            ApplyAdaptiveAdminLayout();
        }

        private void ResizeThumb_DragDelta(object sender, DragDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;

            var canvas = FindParent<Canvas>(thumb);
            var minWidth = canvas != null && canvas.ActualWidth > 0
                ? Math.Max(55, canvas.ActualWidth * 0.04 / sx)
                : 55;

            var minHeight = canvas != null && canvas.ActualHeight > 0
                ? Math.Max(55, canvas.ActualHeight * 0.04 / sy)
                : 55;

            var widthChange = e.HorizontalChange / sx;
            var heightChange = e.VerticalChange / sy;

            // canvas вече е намерен по-горе

            var maxWidth = canvas != null && canvas.ActualWidth > 0
                ? Math.Max(minWidth, (canvas.ActualWidth / sx) - table.PosX)
                : 900;
            var maxHeight = canvas != null && canvas.ActualHeight > 0
                ? Math.Max(minHeight, (canvas.ActualHeight / sy) - table.PosY)
                : 700;

            // Нормално разтягане за всяка форма:
            // - правоъгълник: свободно по ширина и височина;
            // - квадрат и кръг: винаги пазят еднаква ширина и височина.
            if (table.ShapeType == 0 || table.ShapeType == 2)
            {
                var delta = Math.Abs(widthChange) >= Math.Abs(heightChange) ? widthChange : heightChange;
                var minSide = Math.Max(minWidth, minHeight);
                var maxSide = Math.Max(minSide, Math.Min(maxWidth, maxHeight));
                var side = Math.Max(minSide, Math.Min(maxSide, table.Width + delta));
                table.Width = side;
                table.Height = side;
            }
            else
            {
                table.Width = Math.Max(minWidth, Math.Min(maxWidth, table.Width + widthChange));
                table.Height = Math.Max(minHeight, Math.Min(maxHeight, table.Height + heightChange));
            }

            ApplyAdaptiveAdminLayout();
        }


        private void TableThumb_ManipulationDelta(object sender, System.Windows.Input.ManipulationDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;
            var canvas = FindParent<Canvas>(thumb);
            var maxX = canvas != null && canvas.ActualWidth > 0 ? Math.Max(0, (canvas.ActualWidth / sx) - table.Width) : 2000;
            var maxY = canvas != null && canvas.ActualHeight > 0 ? Math.Max(0, (canvas.ActualHeight / sy) - table.Height) : 1200;

            table.PosX = Math.Max(0, Math.Min(maxX, table.PosX + (e.DeltaManipulation.Translation.X / sx)));
            table.PosY = Math.Max(0, Math.Min(maxY, table.PosY + (e.DeltaManipulation.Translation.Y / sy)));
            ApplyAdaptiveAdminLayout();
            e.Handled = true;
        }

        private async void TableThumb_ManipulationCompleted(object sender, System.Windows.Input.ManipulationCompletedEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;
            if (DataContext is AdminFloorViewModel vm)
                await vm.SaveTableLayoutAsync(table);
            e.Handled = true;
        }

        private void ResizeThumb_ManipulationDelta(object sender, System.Windows.Input.ManipulationDeltaEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;
            double sx = _scaleX <= 0 ? 1.0 : _scaleX;
            double sy = _scaleY <= 0 ? 1.0 : _scaleY;
            var canvas = FindParent<Canvas>(thumb);
            var minWidth = canvas != null && canvas.ActualWidth > 0 ? Math.Max(55, canvas.ActualWidth * 0.04 / sx) : 55;
            var minHeight = canvas != null && canvas.ActualHeight > 0 ? Math.Max(55, canvas.ActualHeight * 0.04 / sy) : 55;
            var maxWidth = canvas != null && canvas.ActualWidth > 0 ? Math.Max(minWidth, (canvas.ActualWidth / sx) - table.PosX) : 900;
            var maxHeight = canvas != null && canvas.ActualHeight > 0 ? Math.Max(minHeight, (canvas.ActualHeight / sy) - table.PosY) : 700;
            var widthChange = e.DeltaManipulation.Translation.X / sx;
            var heightChange = e.DeltaManipulation.Translation.Y / sy;

            if (table.ShapeType == 0 || table.ShapeType == 2)
            {
                var delta = Math.Abs(widthChange) >= Math.Abs(heightChange) ? widthChange : heightChange;
                var minSide = Math.Max(minWidth, minHeight);
                var maxSide = Math.Max(minSide, Math.Min(maxWidth, maxHeight));
                var side = Math.Max(minSide, Math.Min(maxSide, table.Width + delta));
                table.Width = side;
                table.Height = side;
            }
            else
            {
                table.Width = Math.Max(minWidth, Math.Min(maxWidth, table.Width + widthChange));
                table.Height = Math.Max(minHeight, Math.Min(maxHeight, table.Height + heightChange));
            }

            ApplyAdaptiveAdminLayout();
            e.Handled = true;
        }

        private static T? FindParent<T>(DependencyObject child)
            where T : DependencyObject
        {
            var parent = VisualTreeHelper.GetParent(child);

            while (parent != null)
            {
                if (parent is T typedParent)
                    return typedParent;

                parent = VisualTreeHelper.GetParent(parent);
            }

            return null;
        }

        private async void TableThumb_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            if (sender is not Thumb thumb) return;
            if (thumb.DataContext is not TableModel table) return;

            // Persist layout immediately when the drag ends
            if (DataContext is AdminFloorViewModel vm)
                await vm.SaveTableLayoutAsync(table);
        }
    }
}
