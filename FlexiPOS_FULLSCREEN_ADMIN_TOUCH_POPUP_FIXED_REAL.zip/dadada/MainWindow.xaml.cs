﻿using Flexi2.ViewModels;
using System.Windows;

namespace Flexi2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
            Loaded += (_, __) => WindowState = WindowState.Maximized;
        }
    }
}