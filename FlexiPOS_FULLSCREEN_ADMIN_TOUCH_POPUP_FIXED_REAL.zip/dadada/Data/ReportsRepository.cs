﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Flexi2.Models;
using static Supabase.Postgrest.Constants;

namespace Flexi2.Data
{
    public sealed class ReportsRepository
    {
        private readonly FlexiDb _db;
        public ReportsRepository(FlexiDb db) => _db = db;

        public async Task<decimal> GetTurnoverSumAsync(DateTime fromUtc, DateTime toUtc)
        {
            var entries = await GetTurnoverEntriesAsync(fromUtc, toUtc, 500);
            return entries.Sum(x => x.TotalAfterDiscount);
        }

        public async Task<List<TurnoverEntry>> GetTurnoverEntriesAsync(DateTime fromUtc, DateTime toUtc, int take = 200)
        {
            try
            {
                var fromLocal = fromUtc.ToLocalTime();
                var toLocal = toUtc.ToLocalTime();

                var ordersResult = await App.SupabaseClient
                    .From<SupabaseOrderRow>()
                    .Get();

                var orders = ordersResult.Models
                    .Where(IsFinishedOrder)
                    .Select(o => new { Order = o, LocalDate = ToLocalSafe(o.ClosedAt ?? o.CreatedAt) })
                    .Where(x => x.LocalDate >= fromLocal && x.LocalDate < toLocal)
                    .OrderByDescending(x => x.LocalDate)
                    .ThenByDescending(x => x.Order.Id)
                    .Take(take)
                    .ToList();

                var result = new List<TurnoverEntry>();

                foreach (var x in orders)
                {
                    var order = x.Order;
                    var itemsText = "";
                    decimal itemsTotal = 0m;

                    try
                    {
                        var items = await App.SupabaseClient
                            .From<SupabaseOrderItemRow>()
                            .Filter("order_id", Operator.Equals, order.Id.ToString())
                            .Get();

                        var cleanItems = items.Models
                            .Where(i => i.Quantity > 0)
                            .OrderBy(i => i.Id)
                            .ToList();

                        itemsText = string.Join(", ", cleanItems.Select(i => $"{i.Quantity} x {i.ProductName}"));
                        itemsTotal = cleanItems.Sum(i => i.Quantity * (i.Price ?? 0m));
                    }
                    catch
                    {
                        itemsText = "";
                        itemsTotal = 0m;
                    }

                    // Истинската сума за отчет: първо paid_total, после total_price, после сбор от артикулите.
                    var total = order.PaidTotal > 0 ? order.PaidTotal : 0m;
                    if (total <= 0 && order.TotalPrice > 0) total = order.TotalPrice;
                    if (total <= 0 && itemsTotal > 0) total = itemsTotal;

                    result.Add(new TurnoverEntry
                    {
                        Id = order.Id,
                        AtUtc = x.LocalDate,
                        UserId = order.CreatedByUserId ?? order.UserId,
                        TableId = order.TableId,
                        TotalAfterDiscount = total,
                        ItemSummary = itemsText
                    });
                }

                return result;
            }
            catch
            {
                return new List<TurnoverEntry>();
            }
        }

        private static bool IsFinishedOrder(SupabaseOrderRow order)
        {
            var status = (order.Status ?? "").Trim().ToLowerInvariant();
            return status == "paid" || status == "closed" || status == "completed" || status == "done" || status == "finished";
        }

        private static DateTime ToLocalSafe(DateTime date)
        {
            if (date.Kind == DateTimeKind.Local) return date;
            if (date.Kind == DateTimeKind.Utc) return date.ToLocalTime();

            // Supabase/Postgrest често връща DateTimeKind.Unspecified.
            // При твоята база часът вече идва като локален час от телефона/WPF.
            // Ако тук го третираме като UTC, WPF добавя +3 часа и отчетът излиза грешно.
            return date;
        }

        // Local fallback, left for compatibility with older parts of the project.
        public decimal GetTurnoverSum(DateTime fromUtc, DateTime toUtc)
        {
            try
            {
                var sum = _db.Scalar<double>(@"
SELECT IFNULL(SUM(PaidTotal),0)
FROM Orders
WHERE IsClosed=1
  AND ClosedAtUtc IS NOT NULL
  AND ClosedAtUtc >= $f
  AND ClosedAtUtc <  $t;",
                c =>
                {
                    c.Parameters.AddWithValue("$f", fromUtc.ToString("O"));
                    c.Parameters.AddWithValue("$t", toUtc.ToString("O"));
                });

                return (decimal)sum;
            }
            catch
            {
                return 0m;
            }
        }

        public List<TurnoverEntry> GetTurnoverEntries(DateTime fromUtc, DateTime toUtc, int take = 200)
        {
            try
            {
                return _db.Query(@"
SELECT o.Id,
       o.ClosedAtUtc,
       o.UserId,
       o.TableId,
       o.PaidTotal,
       IFNULL((
            SELECT GROUP_CONCAT(oi.Qty || ' x ' || oi.ProductName, ', ')
            FROM OrderItems oi
            WHERE oi.OrderId = o.Id
       ), '') AS ItemsText
FROM Orders o
WHERE o.IsClosed=1
  AND o.ClosedAtUtc IS NOT NULL
  AND o.ClosedAtUtc >= $f
  AND o.ClosedAtUtc <  $t
ORDER BY o.Id DESC
LIMIT $n;",
                r => new TurnoverEntry
                {
                    Id = r.GetInt32(0),
                    AtUtc = SafeDate(r.IsDBNull(1) ? "" : r.GetString(1)),
                    UserId = r.IsDBNull(2) ? 0 : r.GetInt32(2),
                    TableId = r.IsDBNull(3) ? 0 : r.GetInt32(3),
                    TotalAfterDiscount = r.IsDBNull(4) ? 0m : (decimal)r.GetDouble(4),
                    ItemSummary = r.IsDBNull(5) ? "" : r.GetString(5)
                },
                c =>
                {
                    c.Parameters.AddWithValue("$f", fromUtc.ToString("O"));
                    c.Parameters.AddWithValue("$t", toUtc.ToString("O"));
                    c.Parameters.AddWithValue("$n", take);
                });
            }
            catch
            {
                return new List<TurnoverEntry>();
            }
        }

        private static DateTime SafeDate(string value)
        {
            if (DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var dt))
            {
                if (dt.Kind == DateTimeKind.Utc) return dt.ToLocalTime();
                return dt;
            }
            return DateTime.Now;
        }
    }
}
