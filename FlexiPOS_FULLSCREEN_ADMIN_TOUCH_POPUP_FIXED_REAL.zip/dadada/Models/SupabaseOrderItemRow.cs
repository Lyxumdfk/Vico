﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;

namespace Flexi2.Models
{
    [Table("order_items")]
    public class SupabaseOrderItemRow : BaseModel
    {
        [PrimaryKey("id", false)]
        public int Id { get; set; }

        [Column("order_id")]
        public int OrderId { get; set; }

        [Column("product_id")]
        public int ProductId { get; set; }

        [Column("product_name")]
        public string ProductName { get; set; } = string.Empty;

        [Column("quantity")]
        public int Quantity { get; set; }

        [Column("unit_price")]
        public decimal? Price { get; set; }

        [Column("ordered_at")]
        public DateTime OrderedAt { get; set; }

        [Column("ordered_by_user_id")]
        public int? OrderedByUserId { get; set; }
    }
}